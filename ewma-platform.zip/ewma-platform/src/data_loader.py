"""
data_loader.py
--------------
Handles market data collection for the EWMA research platform.

Primary source: Yahoo Finance via the `yfinance` package.
A synthetic-data generator is included as a fallback / offline testing tool,
since Yahoo Finance is unreachable in some sandboxed or restricted-network
environments (e.g. corporate proxies, CI runners, this very dev container).

Usage
-----
from src.data_loader import load_price_data

df = load_price_data("AAPL", start="2015-01-01", end="2025-01-01")
"""

from __future__ import annotations

import hashlib
import os
import numpy as np
import pandas as pd


def _deterministic_seed(*parts: str) -> int:
    """
    Derive a stable 32-bit integer seed from arbitrary strings.

    IMPORTANT: Python's built-in `hash()` on strings is randomized per
    process (PEP 456 hash-seed salting) unless `PYTHONHASHSEED` is fixed
    in the environment. That means `hash("AAPL")` returns a *different*
    value every time you start a new Python process — using it to seed
    a synthetic price generator silently breaks reproducibility: the
    "same" ticker/date-range would produce a different random walk on
    every run, every machine, and every notebook restart.

    `hashlib.sha256` is not subject to hash-seed randomization, so it
    gives the same digest for the same input in every process, on every
    machine, forever. That's what reproducibility actually requires.
    """
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()
    return int(digest[:8], 16)  # first 32 bits of the digest as an int



def load_price_data(
    ticker: str,
    start: str = "2015-01-01",
    end: str = "2025-01-01",
    cache_dir: str = "data",
    use_cache: bool = True,
    synthetic_fallback: bool = True,
    clean: bool = True,
    max_daily_return: float = 0.25,
    synthetic_params: dict | None = None,
) -> pd.DataFrame:
    """
    Download OHLCV data for `ticker` between `start` and `end`.

    Tries yfinance first. On failure (no network, rate limit, bad ticker),
    optionally falls back to a synthetic random-walk price series so the
    rest of the pipeline can still be developed/tested offline.

    `synthetic_params`: optional dict of kwargs (e.g. {"annual_drift":
    0.15, "annual_vol": 0.40}) forwarded to generate_synthetic_ohlcv()
    on the fallback path. Without this, EVERY ticker falls back to the
    SAME default statistical regime (annual_drift=0.08, annual_vol=0.25)
    -- fine for testing the pipeline mechanically, but it means a basket
    of "different tickers" all offline is really just different random
    seeds from one distribution, not genuine cross-sectional variation.
    multi_asset.py passes ticker-specific profiles here for exactly that
    reason -- see TICKER_PROFILES there.

    `clean=True` (default) runs the result through `clean_ohlcv()` --
    see that function's docstring. This applies to BOTH the live and the
    synthetic path, and runs after cache reads too, so quality issues in
    a previously-cached file still get caught.

    Returns a DataFrame indexed by Date with columns:
    Open, High, Low, Close, Volume
    """
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = os.path.join(cache_dir, f"{ticker}_{start}_{end}.csv")

    if use_cache and os.path.exists(cache_path):
        df = pd.read_csv(cache_path, index_col=0, parse_dates=True)
        df = _standardize_columns(df)
        return clean_ohlcv(df, max_daily_return=max_daily_return) if clean else df

    try:
        import yfinance as yf

        raw = yf.download(ticker, start=start, end=end, progress=False, auto_adjust=True)
        if raw is None or raw.empty:
            raise ValueError(f"yfinance returned no data for {ticker}")

        # yfinance sometimes returns MultiIndex columns for single tickers
        if isinstance(raw.columns, pd.MultiIndex):
            raw.columns = raw.columns.get_level_values(0)

        df = raw[["Open", "High", "Low", "Close", "Volume"]].copy()
        df.index.name = "Date"

        if use_cache:
            df.to_csv(cache_path)

        return clean_ohlcv(df, max_daily_return=max_daily_return) if clean else df

    except Exception as exc:
        if not synthetic_fallback:
            raise
        print(
            f"[data_loader] Live download failed for '{ticker}' ({exc}). "
            f"Falling back to synthetic data. Set synthetic_fallback=False to disable."
        )
        df = generate_synthetic_ohlcv(ticker, start, end, **(synthetic_params or {}))
        if use_cache:
            df.to_csv(cache_path)
        return clean_ohlcv(df, max_daily_return=max_daily_return) if clean else df


def clean_ohlcv(df: pd.DataFrame, max_daily_return: float = 0.25, verbose: bool = True) -> pd.DataFrame:
    """
    Basic OHLCV data-quality checks and cleaning, applied automatically by
    `load_price_data()`. This is NOT a full institutional-grade data
    pipeline (that needs cross-referencing multiple vendors) -- it catches
    the most common failure modes seen in free market-data feeds like
    yfinance:

      - Duplicate index entries (keeps the last).
      - Missing OHLC values (dropped).
      - Non-positive prices and internally-inconsistent bars (High < Low),
        which indicate corrupted rows rather than real market data
        (dropped).
      - Extreme single-day moves beyond `max_daily_return` (default 25%,
        lowered from an earlier 40% default -- a 40% threshold misses
        common split ratios like 3-for-2 (~33% move) or 5-for-4 (~20%
        move); 25% catches most multi-share-class splits while still
        leaving room above ordinary single-name volatility).
      - Single-day price RATIOS close to a common stock-split factor
        (2, 3, 4, 1.5, 1/2, 1/3, 1/4, 2/3, ...), checked SEPARATELY from
        the magnitude threshold above, specifically because a magnitude
        threshold alone can miss splits whose percentage move happens to
        fall under it (e.g. a 5-for-4 split is only a 20% move).
      - Gaps of more than 7 calendar days between consecutive rows, which
        can indicate a trading halt, delisting, or a feed outage (flagged
        only, not altered).

    None of the "extreme move" or "possible split" checks silently drop
    rows -- genuine extreme moves do happen (halts, acquisitions,
    meme-stock squeezes), so the decision to exclude them is left to you;
    these are printed warnings with the specific dates, not silent edits.

    Returns the cleaned DataFrame; set verbose=False to suppress printed
    diagnostics (e.g. inside a loop over many tickers).
    """
    out = df.copy()
    n_before = len(out)

    out = out[~out.index.duplicated(keep="last")].sort_index()

    price_cols = [c for c in ["Open", "High", "Low", "Close"] if c in out.columns]
    out = out.dropna(subset=price_cols) if price_cols else out

    bad_price = (out[price_cols] <= 0).any(axis=1) if price_cols else pd.Series(False, index=out.index)
    if "High" in out.columns and "Low" in out.columns:
        bad_ohlc = out["High"] < out["Low"]
    else:
        bad_ohlc = pd.Series(False, index=out.index)
    invalid = bad_price | bad_ohlc
    if invalid.any():
        if verbose:
            print(f"[data_loader] Dropping {int(invalid.sum())} row(s) with non-positive or "
                  f"internally inconsistent OHLC values.")
        out = out[~invalid]

    if "Close" in out.columns and len(out) > 1:
        daily_return = out["Close"].pct_change()
        extreme = daily_return.abs() > max_daily_return
        if extreme.any() and verbose:
            flagged = out.index[extreme].strftime("%Y-%m-%d").tolist()
            shown = flagged[:10]
            print(
                f"[data_loader] WARNING: {int(extreme.sum())} day(s) with a >{max_daily_return:.0%} "
                f"single-day move detected -- often an unadjusted stock split or a bad tick, "
                f"though genuine extreme moves do happen. NOT dropped automatically; verify "
                f"manually: {shown}{' ...' if len(flagged) > len(shown) else ''}"
            )

        possible_splits = detect_possible_splits(out["Close"])
        if possible_splits.any() and verbose:
            flagged = out.index[possible_splits].strftime("%Y-%m-%d").tolist()
            shown = flagged[:10]
            print(
                f"[data_loader] WARNING: {int(possible_splits.sum())} day(s) with a price ratio "
                f"close to a common stock-split factor (2x, 3x, 1.5x, 4:1, 3:2, 5:4, ...) detected "
                f"-- checked separately from the magnitude threshold above because some splits "
                f"(e.g. 5-for-4, a ~20% move) fall under it. Verify manually: "
                f"{shown}{' ...' if len(flagged) > len(shown) else ''}"
            )

    if len(out) > 1:
        gaps = out.index.to_series().diff().dt.days
        long_gaps = gaps[gaps > 7]
        if len(long_gaps) > 0 and verbose:
            print(f"[data_loader] Note: {len(long_gaps)} gap(s) of >7 calendar days between "
                  f"consecutive rows (possible trading halt, delisting, or feed outage).")

    n_after = len(out)
    if verbose and n_after != n_before:
        print(f"[data_loader] clean_ohlcv: {n_before} -> {n_after} rows.")

    return out


# Common stock-split ratios (new-shares-per-old-share) and their inverse
# (reverse splits): a price ratio close to a factor OF 1/r or r suggests
# an unadjusted split rather than a genuine price move.
_COMMON_SPLIT_RATIOS = [2, 3, 4, 5, 7, 10, 1.5, 1.25, 4 / 3,
                         1 / 2, 1 / 3, 1 / 4, 1 / 5, 1 / 7, 1 / 10, 2 / 3, 0.8, 3 / 4]


def detect_possible_splits(close: pd.Series, tolerance: float = 0.03) -> pd.Series:
    """
    Flags days where Close[t] / Close[t-1] is within `tolerance` (relative)
    of a common stock-split ratio -- e.g. a 3-for-2 split makes the price
    ratio ~0.667 (a 33% "drop" that a pure magnitude threshold might not
    treat as unusual if the threshold is set above 33%, and WOULD miss
    entirely for something like a 5-for-4 split, ratio ~0.8, only a 20%
    move). This is a pattern match, not a certainty -- a genuine ~33% rally
    or selloff will also match the 3-for-2 ratio; that's why this is a
    warning to verify, not an automatic correction.
    """
    ratio = close / close.shift(1)
    flags = pd.Series(False, index=close.index)
    for r in _COMMON_SPLIT_RATIOS:
        flags = flags | ((ratio - r).abs() < tolerance * r)
    return flags.fillna(False)


def generate_synthetic_ohlcv(
    ticker: str,
    start: str,
    end: str,
    start_price: float = 100.0,
    annual_drift: float = 0.08,
    annual_vol: float = 0.25,
    seed: int | None = None,
) -> pd.DataFrame:
    """
    Generate a plausible daily OHLCV series using geometric Brownian motion.

    Deterministic seed: derived from (ticker, start, end) via SHA-256, so
    the same ticker + same date range always reproduces the exact same
    synthetic price history — across runs, across machines, and across
    Python processes/restarts. Pass an explicit `seed` to override this.

    (Earlier versions of this function seeded with Python's built-in
    `hash(ticker)`, which is randomized per-process and is NOT stable
    across runs — that was a genuine reproducibility bug. Fixed here by
    switching to hashlib.sha256, which is deterministic by design.)
    """
    dates = pd.bdate_range(start=start, end=end)
    n = len(dates)
    if n == 0:
        raise ValueError("start/end produced zero business days")

    rng = np.random.default_rng(
        seed if seed is not None else _deterministic_seed(ticker, str(start), str(end))
    )

    dt = 1 / 252
    mu, sigma = annual_drift, annual_vol
    shocks = rng.normal((mu - 0.5 * sigma**2) * dt, sigma * np.sqrt(dt), n)
    close = start_price * np.exp(np.cumsum(shocks))

    # Build plausible OHLC around the close random walk
    daily_range = np.abs(rng.normal(0, sigma * np.sqrt(dt), n)) * close
    open_ = close * (1 + rng.normal(0, 0.002, n))
    high = np.maximum(open_, close) + daily_range * 0.5
    low = np.minimum(open_, close) - daily_range * 0.5
    volume = rng.integers(1_000_000, 20_000_000, n)

    df = pd.DataFrame(
        {"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume},
        index=dates,
    )
    df.index.name = "Date"
    return df


def _standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    expected = ["Open", "High", "Low", "Close", "Volume"]
    missing = [c for c in expected if c not in df.columns]
    if missing:
        raise ValueError(f"Cached data missing columns: {missing}")
    return df[expected]


if __name__ == "__main__":
    data = load_price_data("AAPL", start="2020-01-01", end="2024-01-01", use_cache=False)
    print(data.head())
    print(data.tail())
    print(f"\nRows: {len(data)}")

    print("\n--- Determinism self-test ---")
    print("(Run this file twice in separate `python3 data_loader.py` invocations")
    print(" and confirm the checksum below is identical both times.)")
    synth = generate_synthetic_ohlcv("AAPL", "2020-01-01", "2024-01-01")
    checksum = round(synth["Close"].sum(), 6)
    print(f"AAPL 2020-01-01..2024-01-01 synthetic Close-sum checksum: {checksum}")

    print("\n--- clean_ohlcv self-test (deliberately corrupted data) ---")
    dirty = generate_synthetic_ohlcv("TEST", "2024-01-01", "2024-03-01").copy()
    dirty.iloc[5, dirty.columns.get_loc("Close")] = -50.0          # bad price
    dirty.iloc[10, dirty.columns.get_loc("High")] = dirty.iloc[10]["Low"] - 5  # High < Low
    dirty.iloc[20, dirty.columns.get_loc("Close")] *= 0.2          # simulated unadjusted 5:1 split (80% move, catches on magnitude too)
    dirty.iloc[30, dirty.columns.get_loc("Close")] *= 0.8          # simulated unadjusted 5-for-4 split: only a 20% move,
                                                                     # UNDER the 25% magnitude threshold -- only the
                                                                     # split-ratio pattern match should catch this one
    print(f"Rows before cleaning: {len(dirty)}")
    cleaned = clean_ohlcv(dirty)
    print(f"Rows after cleaning:  {len(cleaned)} (2 invalid rows dropped; the 80% move should trip the magnitude")
    print("warning; the 20% move should trip ONLY the split-ratio-pattern warning, proving the pattern check")
    print("catches splits the magnitude threshold alone would miss)")

