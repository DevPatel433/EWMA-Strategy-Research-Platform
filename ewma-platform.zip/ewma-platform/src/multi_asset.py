"""
multi_asset.py
---------------
Everything else in this project reports results for one ticker over one
historical window -- which says very little about whether the strategy
generalizes to a different sector, a different decade, or a different
asset class. This module runs the SAME strategy across:

  1. A basket of different tickers (cross-sectional check), and
  2. Several synthetic "market regime" scenarios with deliberately
     different drift/volatility characteristics (cross-regime check).

Two things worth knowing about how these checks behave OFFLINE (no live
market data), since this sandbox has no network access to Yahoo Finance:

  - Cross-sectional: without live data, every ticker used to fall back to
    the SAME default synthetic statistical regime (drift=8%, vol=25%) --
    meaning the "dispersion" across 8 tickers was mostly sampling noise
    from one distribution, not genuine cross-sectional heterogeneity.
    TICKER_PROFILES below gives each fallback ticker a distinct, rough
    drift/vol profile (a low-vol index-like ETF, a high-vol meme stock,
    stable consumer staples, etc.) so the offline cross-sectional check
    is at least testing heterogeneous regimes, not just re-rolling dice
    on the same one. With live data, load_price_data() uses the real
    series and TICKER_PROFILES is simply unused.
  - Cross-regime: each scenario used to run on exactly one random seed --
    a single draw of market history, which is exactly the kind of
    single-path fragility the bootstrap hypothesis test elsewhere in this
    project exists to catch. run_scenario_validation() now runs several
    seeds per scenario and reports mean +/- std, not one point estimate.

IMPORTANT -- survivorship bias: any hard-coded, CURRENT list of tickers
(like DEFAULT_BASKET below) is subject to survivorship bias. A basket
built from today's well-known names implicitly excludes companies that
were delisted, went bankrupt, or were acquired during the backtest
period -- so cross-sectional results from a current-tickers basket will
look systematically better than a point-in-time-correct universe would.
run_cross_sectional_validation() prints an explicit warning whenever it's
called with the default basket, for exactly this reason. There is no
good fix for this without a licensed point-in-time constituents feed;
this module does not attempt to fabricate one.
"""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd

from data_loader import load_price_data, generate_synthetic_ohlcv
from ewma import build_feature_frame
from signals import generate_ewma_crossover_signals, trade_log
from backtester import run_backtest
from metrics import summary

# A deliberately mixed basket (mega-cap tech, financials, energy, consumer
# staples, a historically volatile single name, and a broad-market ETF) --
# still subject to the survivorship-bias caveat above.
DEFAULT_BASKET = ["AAPL", "MSFT", "XOM", "JPM", "KO", "TSLA", "GME", "SPY"]

# Rough, illustrative synthetic-fallback profiles for the tickers in
# DEFAULT_BASKET, so the OFFLINE cross-sectional check has genuine
# cross-sectional heterogeneity instead of 8 draws from one distribution.
# These are NOT fitted to real historical statistics -- just directionally
# sensible (SPY calmer than TSLA/GME, KO calmer than tech, etc.).
TICKER_PROFILES = {
    "AAPL": dict(annual_drift=0.18, annual_vol=0.28),
    "MSFT": dict(annual_drift=0.17, annual_vol=0.24),
    "XOM":  dict(annual_drift=0.06, annual_vol=0.26),
    "JPM":  dict(annual_drift=0.10, annual_vol=0.27),
    "KO":   dict(annual_drift=0.06, annual_vol=0.15),
    "TSLA": dict(annual_drift=0.25, annual_vol=0.55),
    "GME":  dict(annual_drift=0.02, annual_vol=0.80),
    "SPY":  dict(annual_drift=0.11, annual_vol=0.16),
}

# Deliberately different statistical regimes, NOT calibrated to any real
# historical period -- illustrative stress tests, not historical replays.
MARKET_SCENARIOS = {
    "bull_market":          dict(annual_drift=0.20, annual_vol=0.16),
    "bear_market":          dict(annual_drift=-0.15, annual_vol=0.30),
    "choppy_sideways":      dict(annual_drift=0.01, annual_vol=0.20),
    "high_vol_crypto_like": dict(annual_drift=0.10, annual_vol=0.70),
    "low_vol_grind":        dict(annual_drift=0.06, annual_vol=0.10),
}


def run_single_asset(
    prices: pd.DataFrame,
    fast_span: int = 20,
    slow_span: int = 50,
    starting_capital: float = 10_000.0,
    flat_on_sell: bool = True,
    **backtest_kwargs,
) -> dict:
    """Run the full EWMA pipeline on one OHLCV DataFrame and return a metrics dict."""
    feats = build_feature_frame(prices, fast_span=fast_span, slow_span=slow_span)
    signaled = generate_ewma_crossover_signals(feats, flat_on_sell=flat_on_sell)
    bt = run_backtest(signaled, starting_capital=starting_capital, **backtest_kwargs)
    trades = trade_log(signaled)
    return summary(bt, trades)


def run_cross_sectional_validation(
    tickers: list[str] | None = None,
    start: str = "2015-01-01",
    end: str = "2025-01-01",
    fast_span: int = 20,
    slow_span: int = 50,
    starting_capital: float = 10_000.0,
    flat_on_sell: bool = True,
) -> pd.DataFrame:
    """
    Run the strategy on each ticker in `tickers` (default: DEFAULT_BASKET)
    and return one row of metrics per ticker, plus a final "AGGREGATE" row
    summarizing how many tickers had a positive Sharpe / CAGR.

    Tickers unreachable via yfinance fall back to a synthetic series using
    that ticker's TICKER_PROFILES entry if one exists (giving genuine
    cross-sectional heterogeneity offline), else the generic default.
    """
    tickers = list(tickers) if tickers is not None else list(DEFAULT_BASKET)
    if tickers == DEFAULT_BASKET:
        warnings.warn(
            "run_cross_sectional_validation() is using a hard-coded, CURRENT list of "
            "tickers (DEFAULT_BASKET). This introduces survivorship bias: companies "
            "that were delisted, went bankrupt, or were acquired during the backtest "
            "period are invisible from a list built today, which makes cross-sectional "
            "results look systematically better than a point-in-time-correct universe "
            "would. For rigorous cross-sectional research, source POINT-IN-TIME index "
            "constituents (e.g. a historical S&P 500 membership file) instead of a "
            "current ticker list.",
            UserWarning,
            stacklevel=2,
        )

    rows = []
    for ticker in tickers:
        try:
            prices = load_price_data(
                ticker, start=start, end=end, use_cache=False,
                synthetic_params=TICKER_PROFILES.get(ticker),
            )
        except Exception as exc:
            rows.append({"ticker": ticker, "error": str(exc)})
            continue
        try:
            stats = run_single_asset(prices, fast_span, slow_span, starting_capital, flat_on_sell)
            stats["ticker"] = ticker
            rows.append(stats)
        except Exception as exc:
            rows.append({"ticker": ticker, "error": str(exc)})

    df = pd.DataFrame(rows).set_index("ticker")

    if "Sharpe" in df.columns:
        agg = {
            "CAGR": df["CAGR"].mean(),
            "Sharpe": df["Sharpe"].mean(),
            "MaxDrawdown": df["MaxDrawdown"].mean(),
            "FinalValue": df["FinalValue"].mean(),
        }
        pct_positive_sharpe = (df["Sharpe"] > 0).mean()
        agg["pct_tickers_positive_Sharpe"] = pct_positive_sharpe
        df.loc["AGGREGATE (mean)"] = pd.Series(agg)

    return df


def run_scenario_validation(
    scenarios: dict | None = None,
    start: str = "2015-01-01",
    end: str = "2025-01-01",
    fast_span: int = 20,
    slow_span: int = 50,
    starting_capital: float = 10_000.0,
    flat_on_sell: bool = True,
    n_seeds: int = 10,
    base_seed: int = 0,
) -> pd.DataFrame:
    """
    Run the strategy against each named synthetic market regime in
    MARKET_SCENARIOS (or a custom `scenarios` dict of the same shape),
    across `n_seeds` different random draws per scenario, and return one
    row per scenario with MEAN +/- STD Sharpe/CAGR (not a single point
    estimate). This directly tests "does this strategy only work in one
    kind of market?" while also acknowledging that a single simulated
    history per regime -- like a single historical path -- has real
    sampling noise that a point estimate would hide.
    """
    scenarios = scenarios or MARKET_SCENARIOS
    rows = []
    for name, params in scenarios.items():
        sharpes, cagrs, drawdowns = [], [], []
        for i in range(n_seeds):
            prices = generate_synthetic_ohlcv(name, start, end, seed=base_seed + i, **params)
            stats = run_single_asset(prices, fast_span, slow_span, starting_capital, flat_on_sell)
            sharpes.append(stats["Sharpe"])
            cagrs.append(stats["CAGR"])
            drawdowns.append(stats["MaxDrawdown"])

        rows.append({
            "scenario": name,
            "annual_drift": params["annual_drift"], "annual_vol": params["annual_vol"],
            "Sharpe_mean": np.nanmean(sharpes), "Sharpe_std": np.nanstd(sharpes),
            "CAGR_mean": np.nanmean(cagrs), "CAGR_std": np.nanstd(cagrs),
            "MaxDrawdown_mean": np.nanmean(drawdowns),
            "pct_seeds_positive_Sharpe": float(np.mean(np.array(sharpes) > 0)),
            "n_seeds": n_seeds,
        })

    return pd.DataFrame(rows).set_index("scenario")


if __name__ == "__main__":
    pd.set_option("display.width", 160)

    print("=== Cross-sectional validation (basket of tickers, ticker-specific offline profiles) ===")
    cross = run_cross_sectional_validation()
    print(cross[["CAGR", "Sharpe", "MaxDrawdown", "NumTrades"]] if "NumTrades" in cross.columns else cross)

    print("\n=== Cross-regime validation (synthetic market scenarios, multi-seed) ===")
    scenarios = run_scenario_validation(n_seeds=10)
    print(scenarios[["Sharpe_mean", "Sharpe_std", "pct_seeds_positive_Sharpe", "CAGR_mean", "CAGR_std"]])
    print("\nNote the Sharpe_std column: any scenario where std is large relative to the mean")
    print("means a single-seed point estimate (as an earlier version of this function reported)")
    print("could easily have looked very different by chance.")
