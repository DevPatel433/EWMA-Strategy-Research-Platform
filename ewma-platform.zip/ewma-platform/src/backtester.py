"""
backtester.py
-------------
Vectorized backtesting engine with two execution models:

  "next_open" (default, REALISTIC):
      The signal computed from Close[t] is only known after the market
      closes on day t. The earliest price you could actually trade at
      is the following session's Open[t+1]. A position entered there is
      held until the *next* open, so its return is measured open-to-open,
      two bars after the signal that decided it:

          strategy_return[t] = signal[t-2] * (Open[t] - Open[t-1]) / Open[t-1]

  "same_close" (NAIVE, kept only for side-by-side comparison):
      The original 1-day-lag model. It avoids look-ahead bias in the
      sense that it never uses tomorrow's price to compute today's
      signal, but it still implicitly assumes you can transact at the
      exact same close price the signal was calculated from, which is
      not achievable in live trading. Do not use this for evaluating a
      strategy you intend to trade; it is included only so the impact
      of unrealistic execution can be measured and shown.

Also supports (all optional, off by default -- see risk_management.py
for the implementations):
  - stop_loss_pct:  a walk-forward stop-loss overlay on the signal.
  - target_vol:     volatility-target position sizing instead of a flat
                     100%-in-or-out position.
  - use_dynamic_costs: per-day transaction costs that scale with realized
                     volatility and trade size, instead of one constant
                     bps number applied identically to every trade.

Plus a random-signal baseline generator (uses the same execution model
as the strategy, for a fair H0 comparison) and a helper to run both
execution models side-by-side.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def run_backtest(
    df: pd.DataFrame,
    starting_capital: float = 10_000.0,
    signal_col: str = "signal",
    execution_model: str = "next_open",
    transaction_cost_bps: float = 0.0,
    slippage_bps: float = 0.0,
    use_dynamic_costs: bool = False,
    dynamic_cost_kwargs: dict | None = None,
    stop_loss_pct: float | None = None,
    target_vol: float | None = None,
    vol_window: int = 20,
    max_leverage: float = 1.0,
) -> pd.DataFrame:
    """
    Backtest a signal column against OHLC price data.

    execution_model:
      "next_open"  (default) - realistic: signal known at Close[t] is
                    executed at Open[t+1] and held to the next Open.
                    Requires an 'Open' column.
      "same_close" - naive: signal executed at the same Close price it
                    was computed from. Unrealistic; for comparison only.

    transaction_cost_bps, slippage_bps: flat commission/slippage cost in
                    basis points, charged proportional to the SIZE of
                    each position change (so partial-size rebalances
                    under vol targeting cost proportionally less than a
                    full entry/exit, not the same flat per-trade fee).
                    Ignored if use_dynamic_costs=True.

    use_dynamic_costs: if True, replaces the flat bps costs above with
                    risk_management.dynamic_transaction_cost_bps(), which
                    scales with realized volatility (wider effective
                    spread in choppy markets) and with trade size versus
                    average dollar volume (market impact). See
                    dynamic_cost_kwargs to tune it; `position_dollars`
                    defaults to `starting_capital` if not supplied there.

    stop_loss_pct:  if set, applies risk_management.apply_realized_stop_loss()
                    to the ALREADY-LAGGED (realized) position -- forces the
                    position flat starting one bar after price falls more
                    than this fraction below the realized entry fill price.
                    Deliberately uses only a 1-bar exit lag, decoupled from
                    the strategy's own (slower, multi-bar) entry lag, since
                    a stop-loss is a risk control meant to react faster
                    than ordinary signal changes.

    target_vol:     if set, scales the position size (instead of a flat
                    100%-in-or-out) to target this annualized volatility,
                    via risk_management.compute_vol_target_scale(), using
                    the SAME lag as the signal so no extra look-ahead is
                    introduced. `max_leverage` caps the scale (default
                    1.0 = never more than fully invested). Applied AFTER
                    stop_loss_pct, so sizing scales whatever position the
                    stop-loss overlay left in place.
    """
    out = df.copy()

    if "returns" not in out.columns:
        out["returns"] = out["Close"].pct_change()

    effective_signal = out[signal_col]

    if execution_model == "same_close":
        raw_return = out["returns"]
        lag = 1
    elif execution_model == "next_open":
        if "Open" not in out.columns:
            raise ValueError("execution_model='next_open' requires an 'Open' column")
        out["open_returns"] = out["Open"].pct_change()
        raw_return = out["open_returns"]
        # Two-bar lag: one bar for the signal to become known at Close[t],
        # one more bar before the earliest tradable price (Open[t+1]).
        lag = 2
    else:
        raise ValueError(f"Unknown execution_model: {execution_model!r} (use 'next_open' or 'same_close')")

    lagged_signal = effective_signal.shift(lag).fillna(0)

    if stop_loss_pct is not None:
        # Applied to the ALREADY-REALIZED (post entry-lag) position, with
        # its own short exit lag -- a stop-loss should react faster than
        # the strategy's own multi-bar entry logic, not share its lag.
        # See risk_management.apply_realized_stop_loss()'s docstring.
        from risk_management import apply_realized_stop_loss
        execution_price = out["Open"] if execution_model == "next_open" else out["Close"]
        lagged_signal = apply_realized_stop_loss(
            lagged_signal, execution_price, stop_loss_pct=stop_loss_pct, exit_lag=1,
        )

    if target_vol is not None:
        from risk_management import compute_vol_target_scale
        raw_scale = compute_vol_target_scale(out["returns"], target_vol, vol_window, max_leverage)
        lagged_scale = raw_scale.shift(lag).fillna(0)
        lagged_signal = lagged_signal * lagged_scale

    position_delta = lagged_signal.diff().fillna(lagged_signal.iloc[0] if len(lagged_signal) else 0).abs()
    strategy_return = raw_return * lagged_signal

    if use_dynamic_costs:
        from risk_management import dynamic_transaction_cost_bps
        dyn_kwargs = dict(dynamic_cost_kwargs or {})
        dyn_kwargs.setdefault("position_dollars", starting_capital)
        cost_bps_series = dynamic_transaction_cost_bps(out, **dyn_kwargs)
        cost = (cost_bps_series / 10_000.0) * position_delta
        out["dynamic_cost_bps"] = cost_bps_series
    else:
        total_friction_bps = transaction_cost_bps + slippage_bps
        cost = (total_friction_bps / 10_000.0) * position_delta if total_friction_bps > 0 else 0.0

    strategy_return = strategy_return - cost

    out["position_size"] = lagged_signal
    out["strategy_return"] = strategy_return.fillna(0)
    out["portfolio_value"] = starting_capital * (1 + out["strategy_return"]).cumprod()

    # Buy & hold benchmark: realistic single entry at the first available
    # Open (you can't buy at some earlier reference Close either), then
    # marked at each day's Close thereafter.
    if "Open" in out.columns:
        first_open = out["Open"].iloc[0]
        out["buy_hold_value"] = starting_capital * (out["Close"] / first_open)
    else:
        out["buy_hold_value"] = starting_capital * (1 + out["returns"].fillna(0)).cumprod()

    out.attrs["execution_model"] = execution_model
    return out


def compare_execution_models(
    df: pd.DataFrame,
    starting_capital: float = 10_000.0,
    signal_col: str = "signal",
    transaction_cost_bps: float = 0.0,
    slippage_bps: float = 0.0,
) -> pd.DataFrame:
    """
    Run the same signal through both execution models and return a
    side-by-side metrics comparison, to make the cost of the "trade at
    the exact close" assumption visible rather than hidden.
    """
    from metrics import summary

    naive = run_backtest(df, starting_capital, signal_col, "same_close", transaction_cost_bps, slippage_bps)
    realistic = run_backtest(df, starting_capital, signal_col, "next_open", transaction_cost_bps, slippage_bps)

    rows = {
        "Naive (same-close, unrealistic)": summary(naive),
        "Realistic (next-open)": summary(realistic),
    }
    return pd.DataFrame(rows).T


def run_random_baseline(
    df: pd.DataFrame,
    starting_capital: float = 10_000.0,
    execution_model: str = "next_open",
    n_simulations: int = 200,
    long_prob: float = 0.5,
    seed: int = 42,
) -> pd.DataFrame:
    """
    H0 baseline: simulate `n_simulations` random long/flat traders,
    using the SAME execution model as the strategy backtest, so the
    comparison in Section 8 of the report is apples-to-apples (a random
    strategy shouldn't get an unrealistic execution advantage the real
    strategy doesn't have).

    Returns a DataFrame of shape (n_dates, n_simulations) — portfolio
    value for each random run, indexed like `df`.
    """
    rng = np.random.default_rng(seed)

    if execution_model == "next_open":
        if "Open" not in df.columns:
            raise ValueError("execution_model='next_open' requires an 'Open' column")
        rets = df["Open"].pct_change().fillna(0).values
        lag = 2
    elif execution_model == "same_close":
        returns_col = df["returns"] if "returns" in df.columns else df["Close"].pct_change()
        rets = returns_col.fillna(0).values
        lag = 1
    else:
        raise ValueError(f"Unknown execution_model: {execution_model!r}")

    n = len(rets)
    random_signals = (rng.random((n_simulations, n)) < long_prob).astype(int)
    lagged = np.roll(random_signals, lag, axis=1)
    lagged[:, :lag] = 0

    strat_rets = rets[np.newaxis, :] * lagged
    portfolio_paths = starting_capital * np.cumprod(1 + strat_rets, axis=1)

    return pd.DataFrame(portfolio_paths.T, index=df.index, columns=[f"sim_{i}" for i in range(n_simulations)])


if __name__ == "__main__":
    from data_loader import load_price_data
    from ewma import build_feature_frame
    from signals import generate_ewma_crossover_signals
    from metrics import summary

    prices = load_price_data("AAPL", start="2020-01-01", end="2024-01-01")
    feats = build_feature_frame(prices)
    signaled = generate_ewma_crossover_signals(feats, flat_on_sell=True)

    print("=== Realistic (next_open) execution, no frictions ===")
    bt = run_backtest(signaled)
    print(bt[["Close", "Open", "signal", "strategy_return", "portfolio_value", "buy_hold_value"]].tail(10))

    print("\n=== Naive vs. realistic execution: does it matter? ===")
    comparison = compare_execution_models(signaled)
    print(comparison)

    baseline = run_random_baseline(signaled, n_simulations=50)
    print(f"\nRandom baseline (next_open) final value — mean: {baseline.iloc[-1].mean():.2f}, "
          f"median: {baseline.iloc[-1].median():.2f}")
    print(f"Strategy final value: {bt['portfolio_value'].iloc[-1]:.2f}")

    print("\n=== Risk-management options: side-by-side ===")
    variants = {
        "Baseline (no frictions, full size)": run_backtest(signaled),
        "Flat 10bps cost": run_backtest(signaled, transaction_cost_bps=10),
        "Dynamic cost model": run_backtest(signaled, use_dynamic_costs=True),
        "Vol-target sizing (15% target)": run_backtest(signaled, target_vol=0.15),
        "Stop-loss (8%)": run_backtest(signaled, stop_loss_pct=0.08),
        "All combined": run_backtest(signaled, use_dynamic_costs=True, target_vol=0.15, stop_loss_pct=0.08),
    }
    rows = {name: summary(bt_variant) for name, bt_variant in variants.items()}
    print(pd.DataFrame(rows).T[["CAGR", "Sharpe", "MaxDrawdown", "FinalValue"]])
