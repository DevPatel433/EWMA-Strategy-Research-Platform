"""
optimizer.py
------------
Grid-search optimizer over (fast_span, slow_span) EWMA combinations.

This is a lightweight, pure-pandas alternative to VectorBT (Step 8 of the
spec suggests VectorBT for large-scale/optimized backtesting — if it's
installed, `optimize_with_vectorbt` will use it for a much faster sweep;
otherwise `grid_search` below does the same job with the engine already
built in this project).
"""

from __future__ import annotations

import itertools
import pandas as pd

from ewma import add_returns, add_ewma
from signals import generate_ewma_crossover_signals
from backtester import run_backtest
from metrics import summary


def grid_search(
    prices: pd.DataFrame,
    fast_spans: list[int] = (5, 10, 20, 30, 50),
    slow_spans: list[int] = (50, 100, 200),
    starting_capital: float = 10_000.0,
    flat_on_sell: bool = False,
) -> pd.DataFrame:
    """
    Try every valid (fast, slow) combination where fast < slow, backtest
    each, and return a DataFrame of results sorted by Sharpe ratio
    (best first).
    """
    base = add_returns(prices)
    rows = []

    for fast, slow in itertools.product(fast_spans, slow_spans):
        if fast >= slow:
            continue
        feats = add_ewma(base, fast_span=fast, slow_span=slow)
        signaled = generate_ewma_crossover_signals(feats, flat_on_sell=flat_on_sell)
        bt = run_backtest(signaled, starting_capital=starting_capital)
        stats = summary(bt)
        stats["fast_span"] = fast
        stats["slow_span"] = slow
        rows.append(stats)

    results = pd.DataFrame(rows)
    return results.sort_values("Sharpe", ascending=False).reset_index(drop=True)


def optimize_with_vectorbt(
    prices: pd.DataFrame,
    fast_spans: list[int] = (5, 10, 20, 30, 50),
    slow_spans: list[int] = (50, 100, 200),
    starting_capital: float = 10_000.0,
):
    """
    Optional fast path using VectorBT, if installed (`pip install vectorbt`).
    Falls back to a clear ImportError message rather than silently doing
    something else, so users know exactly what to install.
    """
    try:
        import vectorbt as vbt
    except ImportError as exc:
        raise ImportError(
            "vectorbt is not installed. Run `pip install vectorbt` to use "
            "this fast path, or use grid_search() instead (same results, "
            "pure pandas, no extra dependency)."
        ) from exc

    close = prices["Close"]
    fast_ma, slow_ma = vbt.MA.run_combs(
        close, window=list(fast_spans) + list(slow_spans), r=2, short_names=["fast", "slow"]
    )
    entries = fast_ma.ma_crossed_above(slow_ma)
    exits = fast_ma.ma_crossed_below(slow_ma)
    pf = vbt.Portfolio.from_signals(close, entries, exits, init_cash=starting_capital, freq="1D")
    return pf


if __name__ == "__main__":
    from data_loader import load_price_data

    prices = load_price_data("AAPL", start="2018-01-01", end="2024-01-01")
    results = grid_search(prices)
    print(results.head(10).to_string(index=False))
