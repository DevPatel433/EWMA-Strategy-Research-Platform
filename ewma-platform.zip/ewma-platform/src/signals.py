"""
signals.py
----------
Converts EWMA features into trading signals.

Signal convention:
     1  -> long / holding position
    -1  -> flat / out of the market  (kept as -1 to match the original spec;
                                       see NOTE below on interpretation)
     0  -> undefined (only during the initial EWMA warm-up period)

NOTE on -1 vs 0:
Many crossover strategies treat "sell" as simply "go flat" (0), not "go
short" (-1). Both conventions are supported here via `flat_on_sell`:
    flat_on_sell=True   -> sell signal maps to 0 (long-only / flat)
    flat_on_sell=False  -> sell signal maps to -1 (long/short symmetric)
Default is long/short symmetric (-1) to match the original spec, but for
most equity retail strategies flat_on_sell=True is more realistic (you
usually can't costlessly short every asset).
"""

from __future__ import annotations

import pandas as pd


def generate_ewma_crossover_signals(
    df: pd.DataFrame,
    fast_col: str = "EWMA_fast",
    slow_col: str = "EWMA_slow",
    flat_on_sell: bool = False,
) -> pd.DataFrame:
    out = df.copy()

    out["signal"] = 0
    out.loc[out[fast_col] > out[slow_col], "signal"] = 1
    out.loc[out[fast_col] < out[slow_col], "signal"] = -1 if not flat_on_sell else 0

    # Mark actual crossover events (state changes), useful for trade counting
    # and for plotting buy/sell markers.
    prev_signal = out["signal"].shift(1)
    out["crossover"] = 0
    out.loc[(out["signal"] == 1) & (prev_signal != 1), "crossover"] = 1   # BUY event
    out.loc[(out["signal"] != 1) & (prev_signal == 1), "crossover"] = -1  # SELL event

    return out


def trade_log(
    df: pd.DataFrame,
    price_col: str = "Open",
    execution_lag: int = 2,
) -> pd.DataFrame:
    """
    Build a trade log from crossover events: one row per BUY->SELL
    round trip, with entry/exit price, dates, and trade return.

    Fill price realism: a crossover detected using Close[t] cannot be
    filled at Close[t] itself (see backtester.py's docstring for the
    full reasoning). By default this logs the fill at Open, two bars
    after the crossover bar — matching the "next_open" execution model
    used by run_backtest(). Pass price_col="Close", execution_lag=0 to
    reproduce the old (unrealistic) same-bar-close fills for comparison.
    """
    events = df[df["crossover"] != 0][["crossover"]].copy()
    price_series = df[price_col]
    idx = df.index
    trades = []
    entry_date, entry_price = None, None

    for date, row in events.iterrows():
        pos = idx.get_loc(date)
        exec_pos = pos + execution_lag
        if exec_pos >= len(idx):
            continue  # crossover too near the end of the data; no fill available
        exec_date = idx[exec_pos]
        exec_price = price_series.iloc[exec_pos]

        if row["crossover"] == 1:  # BUY
            entry_date, entry_price = exec_date, exec_price
        elif row["crossover"] == -1 and entry_price is not None:  # SELL
            exit_date, exit_price = exec_date, exec_price
            trades.append(
                {
                    "entry_date": entry_date,
                    "exit_date": exit_date,
                    "entry_price": entry_price,
                    "exit_price": exit_price,
                    "return_pct": (exit_price - entry_price) / entry_price,
                }
            )
            entry_date, entry_price = None, None

    return pd.DataFrame(trades)


if __name__ == "__main__":
    from data_loader import load_price_data
    from ewma import build_feature_frame

    prices = load_price_data("AAPL", start="2020-01-01", end="2024-01-01")
    feats = build_feature_frame(prices)
    signaled = generate_ewma_crossover_signals(feats)
    print(signaled[["Close", "EWMA_fast", "EWMA_slow", "signal", "crossover"]].tail(15))
    print("\nTrade log (first 5):")
    print(trade_log(signaled).head())
