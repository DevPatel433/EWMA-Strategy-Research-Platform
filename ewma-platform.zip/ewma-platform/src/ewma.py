"""
ewma.py
-------
Exponentially Weighted Moving Average (EWMA) engine.

Adds fast/slow EWMA columns, daily returns, and basic derived features
(e.g. spread, volatility) used downstream by the signal generator and
the ML regime classifier.
"""

from __future__ import annotations

import pandas as pd


def add_returns(df: pd.DataFrame, price_col: str = "Close") -> pd.DataFrame:
    """Add a `returns` column (simple daily % change) to df."""
    out = df.copy()
    out["returns"] = out[price_col].pct_change()
    return out


def add_ewma(
    df: pd.DataFrame,
    fast_span: int = 20,
    slow_span: int = 50,
    price_col: str = "Close",
) -> pd.DataFrame:
    """
    Add EWMA_fast / EWMA_slow columns and an EWMA_spread (fast - slow),
    which is useful for both signal generation and diagnostics.
    """
    out = df.copy()
    out["EWMA_fast"] = out[price_col].ewm(span=fast_span, adjust=False).mean()
    out["EWMA_slow"] = out[price_col].ewm(span=slow_span, adjust=False).mean()
    out["EWMA_spread"] = out["EWMA_fast"] - out["EWMA_slow"]
    out.attrs["fast_span"] = fast_span
    out.attrs["slow_span"] = slow_span
    return out


def add_volatility(df: pd.DataFrame, window: int = 20, returns_col: str = "returns") -> pd.DataFrame:
    """Add a rolling annualized volatility column, used as a regime feature."""
    out = df.copy()
    if returns_col not in out.columns:
        out = add_returns(out)
    out[f"volatility_{window}d"] = out[returns_col].rolling(window).std() * (252 ** 0.5)
    return out


def build_feature_frame(
    df: pd.DataFrame,
    fast_span: int = 20,
    slow_span: int = 50,
    vol_window: int = 20,
) -> pd.DataFrame:
    """Convenience pipeline: returns -> EWMA -> volatility, in one call."""
    out = add_returns(df)
    out = add_ewma(out, fast_span=fast_span, slow_span=slow_span)
    out = add_volatility(out, window=vol_window)
    return out


if __name__ == "__main__":
    from data_loader import load_price_data

    prices = load_price_data("AAPL", start="2020-01-01", end="2024-01-01")
    feats = build_feature_frame(prices)
    print(feats[["Close", "EWMA_fast", "EWMA_slow", "EWMA_spread", "returns"]].tail(10))
