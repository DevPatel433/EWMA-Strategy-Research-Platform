"""
risk_management.py
-------------------
Three things a "100%-in-or-100%-out, flat-fee" backtest is missing:

  1. Transaction costs that actually respond to market conditions and
     trade size (dynamic_transaction_cost_bps), instead of one constant
     bps number applied identically whether the market is calm or
     chaotic, whether the name is liquid or thin.
  2. Position sizing (compute_vol_target_scale) -- real trading doesn't
     bet the same fraction of capital regardless of how risky conditions
     currently are.
  3. A stop-loss overlay (apply_stop_loss) -- a rule that only ever exits
     on the *next* crossover, with no protection between crossovers, can
     ride a large adverse move all the way down before the indicator
     catches up.

None of this makes the strategy "safe" or removes the need for judgment;
it replaces a few silently-optimistic defaults with explicit, adjustable
assumptions.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def compute_vol_target_scale(
    returns: pd.Series,
    target_vol: float = 0.15,
    vol_window: int = 20,
    max_leverage: float = 1.0,
) -> pd.Series:
    """
    Volatility-target position-sizing scale: instead of always being
    100% in or 100% out, size the position so its *expected* annualized
    volatility is approximately `target_vol`, using trailing realized
    volatility as the estimate. This is a standard, simple form of risk
    management ("vol targeting" / a crude risk-parity sizing) -- it
    automatically sizes DOWN when markets get choppy and sizes UP (up to
    `max_leverage`) when markets are calm, which tends to reduce max
    drawdown relative to constant full-size exposure.

    Returns a scale in [0, max_leverage] aligned to `returns.index`. This
    is combined with the discrete +-1/0 signal by simple multiplication;
    the caller is responsible for using the same lag on both series so
    no additional look-ahead is introduced beyond what the signal itself
    already uses.
    """
    realized_vol = returns.rolling(vol_window).std() * np.sqrt(252)
    scale = (target_vol / realized_vol).clip(lower=0.0, upper=max_leverage)
    return scale.fillna(0.0)


def apply_stop_loss(
    df: pd.DataFrame,
    signal_col: str = "signal",
    price_col: str = "Close",
    stop_loss_pct: float = 0.08,
) -> pd.Series:
    """
    DEPRECATED (kept for backward compatibility / reference only) --
    applies the stop-loss to the RAW, pre-execution-lag signal, which
    means a stop-out still has to flow through the same multi-bar entry
    lag as everything else before it actually takes effect. That defeats
    the point of a stop-loss, which exists to react FASTER than the
    strategy's normal (realistically slow) signal logic. Use
    `apply_realized_stop_loss()` instead, which operates on the
    already-lagged/realized position and gives the stop its own short
    exit lag, decoupled from the entry lag.
    """
    signal = df[signal_col].to_numpy()
    price = df[price_col].to_numpy()
    n = len(signal)
    out = np.zeros(n, dtype=int)

    in_position = False
    entry_price = None
    stopped_out = False

    for i in range(n):
        raw = signal[i]

        if raw != 1:
            in_position = False
            entry_price = None
            stopped_out = False
        elif raw == 1 and not in_position and not stopped_out:
            in_position = True
            entry_price = price[i]

        if in_position and entry_price:
            drawdown = (price[i] - entry_price) / entry_price
            if drawdown <= -stop_loss_pct:
                in_position = False
                stopped_out = True

        out[i] = 1 if in_position else 0

    return pd.Series(out, index=df.index, name=f"{signal_col}_sl")


def apply_realized_stop_loss(
    lagged_position: pd.Series,
    execution_price: pd.Series,
    stop_loss_pct: float = 0.08,
    exit_lag: int = 1,
) -> pd.Series:
    """
    Stop-loss applied to the ALREADY-REALIZED position (i.e. the signal
    AFTER the strategy's own entry lag has been applied -- what you're
    actually holding on each day), not to the raw pre-lag signal.

    This matters: a stop-loss is a risk CONTROL that should react faster
    than the strategy's own realistically-slow multi-bar entry logic.
    Coupling stop-loss exits to that same entry lag (as an earlier
    version of this function did) makes a "stop-loss" no faster than an
    ordinary signal change -- which defeats the purpose of having one.

    Monitors `execution_price` (the same price series the position is
    marked at, e.g. Open under the next-open execution model) for a
    drawdown from the REALIZED entry fill price. When a breach is
    detected on day i, the position is forced flat starting day
    i + exit_lag (default 1: "notice the breach using today's price,
    exit at the next available price") -- the minimum lag achievable
    with daily-bar data, independent of however many bars the entry
    signal itself needed.

    Once forced flat by a stop, stays flat until the underlying realized
    position itself returns to 0 on its own (a normal signal-driven
    exit) -- so a stop-out doesn't instantly re-trigger a re-entry the
    very next bar while the underlying rule is technically still "long".

    Returns a new position series in the same (already-lagged) timeframe
    as `lagged_position` -- do NOT lag this again before backtesting it.
    """
    pos = lagged_position.to_numpy().astype(float)
    price = execution_price.to_numpy()
    n = len(pos)
    out = pos.copy()

    in_position = False
    entry_price = None
    stop_trigger_day = None
    suppressed = False

    for i in range(n):
        if pos[i] <= 0:
            in_position = False
            entry_price = None
            stop_trigger_day = None
            suppressed = False
            continue

        if suppressed:
            out[i] = 0.0
            continue

        if not in_position:
            in_position = True
            entry_price = price[i]

        if entry_price and not np.isnan(price[i]):
            drawdown = (price[i] - entry_price) / entry_price
            if drawdown <= -stop_loss_pct and stop_trigger_day is None:
                stop_trigger_day = i

        if stop_trigger_day is not None and i >= stop_trigger_day + exit_lag:
            out[i] = 0.0
            suppressed = True

    name = f"{lagged_position.name}_sl" if lagged_position.name else "position_sl"
    return pd.Series(out, index=lagged_position.index, name=name)


def dynamic_transaction_cost_bps(
    df: pd.DataFrame,
    position_dollars: float,
    base_spread_bps: float = 5.0,
    vol_scaling: float = 4.0,
    impact_coefficient: float = 15.0,
    adv_window: int = 20,
) -> pd.Series:
    """
    Per-day estimated round-trip friction in basis points, combining two
    effects a single flat bps number can't capture:

      - A bid-ask half-spread proxy that WIDENS with realized volatility
        (spreads are empirically wider in choppier markets). `vol_scaling`
        is "extra bps of spread per 1 percentage-point of daily volatility":
            spread_bps = base_spread_bps + vol_scaling * (daily_vol * 100)
        e.g. base=5, vol_scaling=4, daily_vol=1.5% -> 5 + 4*1.5 = 11 bps.

      - A square-root market-impact cost (in the style of Almgren et al.)
        based on the assumed trade's share of trailing average dollar
        volume (ADV) -- costs rise for less liquid names and bigger
        orders relative to how much typically trades:
            impact_bps = impact_coefficient * sqrt(position_dollars / ADV)

    `position_dollars` is treated as a fixed reference order size (e.g.
    the starting capital) rather than a compounding, path-dependent
    portfolio value -- a deliberate simplification so this stays a
    simple vectorized per-day series rather than a circular solve. This
    is a stylized, illustrative cost model, not a broker- or
    venue-calibrated one -- but it captures the right QUALITATIVE
    behavior: costs rise in high-volatility regimes and for less liquid
    names, which a flat bps fee cannot represent at all. Sanity check:
    for a liquid large-cap in modest size and calm markets this should
    land in the ~5-15 bps range, not hundreds of bps -- if you see
    triple-digit output, position_dollars is probably too large relative
    to the asset's actual dollar volume.
    """
    if "returns" not in df.columns:
        daily_vol = df["Close"].pct_change().rolling(adv_window).std().fillna(0)
    else:
        daily_vol = df["returns"].rolling(adv_window).std().fillna(0)
    spread_bps = base_spread_bps + vol_scaling * (daily_vol * 100)

    dollar_volume = (df["Close"] * df["Volume"]).rolling(adv_window).mean()
    participation = (position_dollars / dollar_volume).clip(lower=0).fillna(0)
    impact_bps = impact_coefficient * np.sqrt(participation)

    return (spread_bps + impact_bps).fillna(base_spread_bps)


if __name__ == "__main__":
    from data_loader import load_price_data
    from ewma import build_feature_frame
    from signals import generate_ewma_crossover_signals

    prices = load_price_data("AAPL", start="2020-01-01", end="2024-01-01")
    feats = build_feature_frame(prices)
    signaled = generate_ewma_crossover_signals(feats, flat_on_sell=True)

    print("=== Vol-target sizing scale (tail) ===")
    scale = compute_vol_target_scale(signaled["returns"], target_vol=0.15)
    print(scale.tail())

    print("\n=== Stop-loss overlay: trades affected (old, deprecated pre-lag version) ===")
    sl_signal = apply_stop_loss(signaled, stop_loss_pct=0.08)
    n_forced_flat_days = int(((signaled["signal"] == 1) & (sl_signal == 0)).sum())
    print(f"Days where the raw signal said 'long' but the stop-loss forced flat: {n_forced_flat_days}")

    print("\n=== apply_realized_stop_loss: hand-checkable timing test ===")
    dates = pd.date_range("2024-01-01", periods=8, freq="B")
    lagged_pos = pd.Series([0, 1, 1, 1, 1, 1, 0, 0], index=dates, dtype=float)
    # Entry fills at 100 (day 1), then price craters to trigger an 8% stop on day 3 (94 vs 100 = -6%; day4=90 -> -10%, breach)
    exec_price = pd.Series([99, 100, 97, 90, 89, 88, 87, 87], index=dates, dtype=float)
    sl = apply_realized_stop_loss(lagged_pos, exec_price, stop_loss_pct=0.08, exit_lag=1)
    print(pd.DataFrame({"lagged_position": lagged_pos, "exec_price": exec_price, "stop_adjusted": sl}))
    print("Expect: breach detected day index 3 (price=90, drawdown -10% from entry=100);")
    print("        forced flat starts day index 4 (breach_day + exit_lag=1), stays flat until")
    print("        the underlying position itself returns to 0 at index 6.")

    print("\n=== Dynamic transaction cost (bps), tail ===")
    dyn_cost = dynamic_transaction_cost_bps(signaled, position_dollars=10_000)
    print(dyn_cost.describe())
