"""
metrics.py
----------
Performance analytics for a backtested strategy: CAGR, Sharpe ratio,
max drawdown, volatility, win rate, plus a convenience `summary()`
that returns all of them as a single dict/DataFrame row.

Risk-free rate handling: Sharpe ratios computed with a flat 0% risk-free
rate silently overstate risk-adjusted performance during any period
where actual short-term rates were meaningfully positive -- and 2015-2025
ranged from roughly 0% to roughly 5%. `sharpe_ratio()` now defaults to a
time-varying approximate historical rate (see `historical_risk_free_rate`
below) instead of hardcoding 0%.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

TRADING_DAYS_PER_YEAR = 252

# Rough, illustrative annualized risk-free rate by calendar year (approx.
# 3-month T-bill / Fed Funds level). This is NOT a substitute for actual
# daily Treasury-yield data (e.g. FRED series DGS3MO) -- it exists only
# so Sharpe ratios stop silently assuming free money across a decade that
# included both near-zero and ~5% rate regimes. For rigorous work, pass
# a real daily risk-free series into `risk_free_rate=` instead.
_HISTORICAL_RISK_FREE_RATE_BY_YEAR = {
    2014: 0.0003, 2015: 0.0005, 2016: 0.0032, 2017: 0.0093, 2018: 0.0194,
    2019: 0.0214, 2020: 0.0035, 2021: 0.0004, 2022: 0.0168, 2023: 0.0485,
    2024: 0.0510, 2025: 0.0430, 2026: 0.0400,
}
_RF_FALLBACK = 0.02  # used for any year outside the table above


def historical_risk_free_rate(dates) -> pd.Series:
    """
    Approximate annualized risk-free rate for each date, based on the
    coarse by-year table above. Returned as a pd.Series aligned to
    `dates` so it can be subtracted from a daily returns series after
    converting to a daily rate.
    """
    idx = pd.DatetimeIndex(dates)
    rates = [_HISTORICAL_RISK_FREE_RATE_BY_YEAR.get(y, _RF_FALLBACK) for y in idx.year]
    return pd.Series(rates, index=idx, name="risk_free_rate")


def cagr(portfolio_value: pd.Series) -> float:
    """Compound Annual Growth Rate from a portfolio value series."""
    pv = portfolio_value.dropna()
    if len(pv) < 2 or pv.iloc[0] <= 0:
        return np.nan
    n_years = len(pv) / TRADING_DAYS_PER_YEAR
    if n_years <= 0:
        return np.nan
    return (pv.iloc[-1] / pv.iloc[0]) ** (1 / n_years) - 1


def excess_cagr(portfolio_value: pd.Series, risk_free_rate=None) -> float:
    """
    CAGR minus the average annualized risk-free rate over the period --
    a simple risk-adjusted absolute-return figure to sit alongside CAGR.
    `risk_free_rate` accepts the same inputs as `sharpe_ratio()`.
    """
    c = cagr(portfolio_value)
    if np.isnan(c):
        return np.nan
    rf_avg = _resolve_risk_free_series(portfolio_value.index, risk_free_rate).mean()
    return c - rf_avg


def _resolve_risk_free_series(index, risk_free_rate) -> pd.Series:
    """Normalize risk_free_rate (None | float | pd.Series) into an annualized rate series aligned to `index`."""
    if risk_free_rate is None:
        return historical_risk_free_rate(index)
    if isinstance(risk_free_rate, (int, float)):
        return pd.Series(float(risk_free_rate), index=index)
    return risk_free_rate.reindex(index).ffill().bfill()


def sharpe_ratio(returns: pd.Series, risk_free_rate=None) -> float:
    """
    Annualized Sharpe ratio from a daily returns series.

    risk_free_rate:
      None (default) - use the approximate historical annual rate for
                        each year in `returns.index` (see
                        `historical_risk_free_rate`).
      float           - a single flat annualized rate applied throughout
                        (e.g. 0.0 to reproduce the old always-0% behavior).
      pd.Series        - a time-varying annualized rate, reindexed to
                        `returns.index` (use this with real Treasury data
                        for rigorous work).
    """
    r = returns.dropna()
    if len(r) < 2 or r.std() == 0:
        return np.nan
    rf_annual = _resolve_risk_free_series(r.index, risk_free_rate)
    daily_rf = rf_annual / TRADING_DAYS_PER_YEAR
    excess = r - daily_rf
    return (excess.mean() / excess.std()) * np.sqrt(TRADING_DAYS_PER_YEAR)


def max_drawdown(portfolio_value: pd.Series) -> float:
    """Largest peak-to-trough decline, expressed as a negative fraction."""
    pv = portfolio_value.dropna()
    if pv.empty:
        return np.nan
    running_max = pv.cummax()
    drawdown = (pv - running_max) / running_max
    return drawdown.min()


def annualized_volatility(returns: pd.Series) -> float:
    r = returns.dropna()
    if r.empty:
        return np.nan
    return r.std() * np.sqrt(TRADING_DAYS_PER_YEAR)


def win_rate(trades: pd.DataFrame, return_col: str = "return_pct") -> float:
    """Fraction of trades with positive return, from a trade log DataFrame."""
    if trades.empty:
        return np.nan
    return (trades[return_col] > 0).mean()


def summary(
    df: pd.DataFrame,
    trades: pd.DataFrame | None = None,
    portfolio_col: str = "portfolio_value",
    returns_col: str = "strategy_return",
    risk_free_rate=None,
) -> dict:
    """
    Compute all metrics at once and return them as a dict.
    risk_free_rate: None (default, historical approximation), a flat
    float, or a pd.Series -- see `sharpe_ratio()`.
    """
    result = {
        "CAGR": cagr(df[portfolio_col]),
        "ExcessCAGR": excess_cagr(df[portfolio_col], risk_free_rate),
        "Sharpe": sharpe_ratio(df[returns_col], risk_free_rate),
        "MaxDrawdown": max_drawdown(df[portfolio_col]),
        "AnnualVolatility": annualized_volatility(df[returns_col]),
        "FinalValue": df[portfolio_col].iloc[-1],
    }
    if trades is not None:
        result["NumTrades"] = len(trades)
        result["WinRate"] = win_rate(trades)
    return result


def summary_table(*named_results: tuple[str, dict]) -> pd.DataFrame:
    """Combine several summary() dicts into a comparison table."""
    return pd.DataFrame({name: res for name, res in named_results}).T


if __name__ == "__main__":
    from data_loader import load_price_data
    from ewma import build_feature_frame
    from signals import generate_ewma_crossover_signals, trade_log
    from backtester import run_backtest

    prices = load_price_data("AAPL", start="2020-01-01", end="2024-01-01")
    feats = build_feature_frame(prices)
    signaled = generate_ewma_crossover_signals(feats)
    bt = run_backtest(signaled)
    trades = trade_log(signaled)

    strat_summary = summary(bt, trades)
    bh_summary = {
        "CAGR": cagr(bt["buy_hold_value"]),
        "ExcessCAGR": excess_cagr(bt["buy_hold_value"]),
        "Sharpe": sharpe_ratio(bt["returns"]),
        "MaxDrawdown": max_drawdown(bt["buy_hold_value"]),
        "AnnualVolatility": annualized_volatility(bt["returns"]),
        "FinalValue": bt["buy_hold_value"].iloc[-1],
    }

    table = summary_table(("EWMA Strategy", strat_summary), ("Buy & Hold", bh_summary))
    print(table)

    print("\n--- Risk-free rate sensitivity check ---")
    print(f"Sharpe with 0% flat risk-free rate:        {sharpe_ratio(bt['strategy_return'], risk_free_rate=0.0):.4f}")
    print(f"Sharpe with historical approx. risk-free:  {sharpe_ratio(bt['strategy_return']):.4f}")
    print(f"Average historical approx. rate over period: {historical_risk_free_rate(bt.index).mean():.2%}")
