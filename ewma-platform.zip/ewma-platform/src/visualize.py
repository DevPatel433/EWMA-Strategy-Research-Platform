"""
visualize.py
------------
Step 7 of the spec: charts.

  1. price + EWMA fast/slow lines
  2. buy/sell markers (from the `crossover` column)
  3. portfolio growth vs. buy & hold

Matplotlib-based so it works in notebooks, scripts, and the Streamlit
dashboard (st.pyplot(fig)).
"""

from __future__ import annotations

import matplotlib.pyplot as plt
import pandas as pd


def plot_price_and_ewma(df: pd.DataFrame, price_col: str = "Close", title: str = "Price & EWMA"):
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(df.index, df[price_col], label=price_col, color="black", linewidth=1)
    ax.plot(df.index, df["EWMA_fast"], label=f"Fast EWMA ({df.attrs.get('fast_span', '')})", color="tab:blue")
    ax.plot(df.index, df["EWMA_slow"], label=f"Slow EWMA ({df.attrs.get('slow_span', '')})", color="tab:orange")
    ax.set_title(title)
    ax.set_xlabel("Date")
    ax.set_ylabel("Price")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    return fig


def plot_signals(df: pd.DataFrame, price_col: str = "Close", title: str = "Buy / Sell Signals"):
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(df.index, df[price_col], label=price_col, color="black", linewidth=1, alpha=0.7)

    buys = df[df["crossover"] == 1]
    sells = df[df["crossover"] == -1]
    ax.scatter(buys.index, buys[price_col], marker="^", color="green", s=90, label="BUY", zorder=5)
    ax.scatter(sells.index, sells[price_col], marker="v", color="red", s=90, label="SELL", zorder=5)

    ax.set_title(title)
    ax.set_xlabel("Date")
    ax.set_ylabel("Price")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    return fig


def plot_portfolio_growth(
    df: pd.DataFrame,
    strategy_col: str = "portfolio_value",
    benchmark_col: str = "buy_hold_value",
    title: str = "Portfolio Growth: Strategy vs. Buy & Hold",
):
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(df.index, df[strategy_col], label="EWMA Strategy", color="tab:blue", linewidth=1.5)
    if benchmark_col in df.columns:
        ax.plot(df.index, df[benchmark_col], label="Buy & Hold", color="gray", linewidth=1.2, linestyle="--")
    ax.set_title(title)
    ax.set_xlabel("Date")
    ax.set_ylabel("Portfolio Value ($)")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    return fig


def plot_drawdown(df: pd.DataFrame, portfolio_col: str = "portfolio_value", title: str = "Drawdown"):
    pv = df[portfolio_col]
    running_max = pv.cummax()
    drawdown = (pv - running_max) / running_max

    fig, ax = plt.subplots(figsize=(12, 3.5))
    ax.fill_between(df.index, drawdown * 100, 0, color="tab:red", alpha=0.4)
    ax.set_title(title)
    ax.set_ylabel("Drawdown (%)")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    return fig


if __name__ == "__main__":
    from data_loader import load_price_data
    from ewma import build_feature_frame
    from signals import generate_ewma_crossover_signals
    from backtester import run_backtest

    prices = load_price_data("AAPL", start="2020-01-01", end="2024-01-01")
    feats = build_feature_frame(prices)
    signaled = generate_ewma_crossover_signals(feats)
    bt = run_backtest(signaled)

    plot_price_and_ewma(bt).savefig("../data/_test_price_ewma.png", dpi=100)
    plot_signals(bt).savefig("../data/_test_signals.png", dpi=100)
    plot_portfolio_growth(bt).savefig("../data/_test_portfolio.png", dpi=100)
    plot_drawdown(bt).savefig("../data/_test_drawdown.png", dpi=100)
    print("Saved 4 test charts to data/")
